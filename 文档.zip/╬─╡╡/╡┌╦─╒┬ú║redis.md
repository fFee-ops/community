## Redis入门

![image-20211213160350868](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211213160350868.png)

## SpringBoot整合Redis

![image-20211213170836531](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211213170836531.png)

1、导包

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

2、在配置文件中配置

```properties
#RedisProperties
spring.redis.database=11
spring.redis.host=47.93.98.210
spring.redis.port=6379
```

3、编写配置类

```java
@Configuration
public class RedisConfig {

    @Bean
    public RedisTemplate<String,Object> redisTemplate(RedisConnectionFactory factory){
        //实例化bean
        RedisTemplate<String,Object> template=new RedisTemplate<>();
        //将工厂设置给template（具有了访问数据库的能力）
        template.setConnectionFactory(factory);
        //序列化的方式（数据转换的方式）
        //设置key的序列化方式
        template.setKeySerializer(RedisSerializer.string());

        //设置value的序列化方式
        template.setValueSerializer(RedisSerializer.json());

        //设置hash的key的序列化方式
        template.setHashKeySerializer(RedisSerializer.string());

        //设置hash的value的序列化方式
        template.setHashValueSerializer(RedisSerializer.json());

        //将设置生效
        template.afterPropertiesSet();

        return template;

    }
}
```

## 点赞

![image-20211213202556719](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211213202556719.png)

存数据key反复复用，比较容易记，写一个工具专门去用于产生key

![image-20211213204104017](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211213204104017.png)

```
帖子和评论统称为实体
```

业务层

```java
@Service
public class LikeService {

    @Autowired
    private RedisTemplate redisTemplate;

    //点赞
    public void like(int userId,int entityType,int entityId){
        //拼接出key
        String entityLikeKey= RedisKeyUtil.getEntityLikeKey(entityType,entityId);
        //判断当前用户有没有点过赞（userid在不在set集合里）
        boolean isMember=redisTemplate.opsForSet().isMember(entityLikeKey,userId);
        //已经点过赞了，取消赞（将userid在set集合中remove）
        if(isMember){
            redisTemplate.opsForSet().remove(entityLikeKey,userId);
        }else {//没点过，添加数据
            redisTemplate.opsForSet().add(entityLikeKey,userId);

        }
    }

    //查询某实体点赞的数量
    public long findEntityLikeCount(int entityType,int entityId){
        //得到key
        String entityLikeKey=RedisKeyUtil.getEntityLikeKey(entityType,entityId);
        //在set集合中查看key对应有几个value
        return redisTemplate.opsForSet().size(entityLikeKey);

    }

    //查询某人对某实体的点赞状态,返回整数更具有扩展性，以后还可以开发踩帖子的功能
    public int findEntityLikeStatus(int userId,int entityType,int entityId){
        //拼接出key
        String entityLikeKey= RedisKeyUtil.getEntityLikeKey(entityType,entityId);
        //判断value集合中是否有该userid
        return redisTemplate.opsForSet().isMember(entityLikeKey,userId) ? 1:0;
    }

}
```

表现层：异步刷新，不用更新整个页面

![image-20211213213259394](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211213213259394.png)

1开头的是帖子，2开头的是评论

对之前的帖子、评论、回复进行重构，将点赞状态和点赞数量信息添加到相应的vo页面表现集合里面。

![image-20211214141032408](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214141032408.png)

![image-20211214141115043](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214141115043.png)

![image-20211214141142588](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214141142588.png)

## 我收到的赞

![image-20211214142337540](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214142337540.png)

 解决redis乱码问题：redis-cli --raw



## 关注、取消关注

![image-20211214141205069](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214141205069.png)

![image-20211214172912700](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211214172912700.png)

![image-20211217144626877](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211217144626877.png)

## 关注列表、粉丝列表

![image-20211217144709137](https://img-1302474103.cos.ap-nanjing.myqcloud.com/img/image-20211217144709137.png)

## 个人主页的我的回复

![image-20211221104830709](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221104830709.png)

![image-20211221104904377](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221104904377.png)

```java
//查找某用户曾经为帖子发布过的评论
@RequestMapping(path = "/selectReply/{userId}",method = RequestMethod.GET)
public String findComment(@PathVariable("userId")int userId,
                          Page page,Model model){
    //查找user
    User user = userService.findUserById(userId);
    //判断用户是否存在
    if(user==null){
        throw new RuntimeException("用户不存在！");
    }
    //将用户添加到model
    model.addAttribute("user",user);
    //设置分页信息
    page.setLimit(3);
    page.setPath("/user/selectComment/"+userId);
    page.setRows(commentService.findUserCount(userId));

    //查找某用户曾经为帖子发布过的评论
    List<Comment> comments = commentService.findUserComments(userId, page.getoffset(), page.getLimit());
    // 判断集合是否为空
    if(comments==null){
        return null;
    }

    List<Map<String,Object>> list=new ArrayList<>();
    for (Comment comment : comments) {
        Map<String,Object> map=new HashMap<>();
        //将评论保存起来
        map.put("comment",comment);
        //找到回复对应的帖子
        DiscussPost discussPost = discussPostService.findDiscussDetail(comment.getEntityId());
        map.put("discussPost",discussPost);

        list.add(map);
    }

    model.addAttribute("comments",list);

    return "/site/my-reply";
}
```

## 优化登陆模块

![image-20211221105020595](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221105020595.png)

存验证码：



1.定义redis的key

![image-20211221105429382](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221105429382.png)

拼接验证码的key

不同的用户验证码不同，识别用户是谁，在用户访问登录页面的时候给他发一个凭证（随机生成的字符串，存到cookie里面），很快让字符串过期即可。

![image-20211221105720694](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221105720694.png)

获取验证码方法重构

将验证码存到redis里面，那就需要key，key有需要随机字符串，所以先写生成随机字符串

凭证需要发给客户端（浏览器），在cookie中保存，并设置过期时间和生效路径

添加到response里面

将验证码存入redis



2）redis记录登陆凭证



将ticket字符串传入



将之前的login_ticket表废弃掉，登陆之后生成凭证，退出之后销毁凭证，查询凭证的方法

![image-20211221140118905](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221140118905.png)

销毁凭证就是在redis里面先将值取出来再将值修改一下再存进去（1表示删除态）

![image-20211221140230413](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221140230413.png)

![image-20211221140258473](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211221140258473.png)

后续的开发可能会用到redis里面的凭证，所以退出时只是修改凭证而不是删除，但是用户信息是临时存一下，提高效率而已，还有user表，要删除的话就直接删除

在查询user的时候先尝试在redis里面取值，取不到再初始化进去，修改用户数据后（头像密码），删除缓存。