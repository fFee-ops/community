# 要启动的东西

1、zk

```shell
cd D:\Softwares\kafka\kafka_2.12-2.3.0\bin
windows\zookeeper-server-start.bat ..\config\zookeeper.properties
```

2、kafka

```shell
cd D:\Softwares\kafka\kafka_2.12-2.3.0
bin\windows\kafka-server-start.bat config\server.properties

要用stop脚本才能关闭
```

3、redis（linux）

```shell
cd /usr/local/redis
./bin/redis-server ./redis.conf
```

4、es

```shell
D:\Softwares\elasticSearch\es6.4.3\elasticsearch-6.4.3\bin目录下执行elasticsearch.bat
```

