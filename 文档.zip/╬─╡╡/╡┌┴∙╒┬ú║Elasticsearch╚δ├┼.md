## Elasticsearch入门

分布式搜索引擎

![image-20211222193109098](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222193109098.png)

结构化、非结构化、地理位置。

搜索引擎搜索：1，提交数据到搜索引擎（它再存一份，它还会建立索引提高效率）

es中的索引-----》mysql中的数据库database

es中的类型----》mysql中的表table

es中的文档（数据结构为json）-----》msql中的一张表中的一行数据row

json当中的每一个属性叫字段------》mysql中的一列col

从6.0之后

es的索引----》mysql的表，  类型逐渐废弃

多台服务器构成集群，集群中的每台服务器称为节点，一个索引（一个表）数据很多，对索引进一步划分存储，并发能力提高，副本是对分片的备份。

修改配置

![image-20211222195016095](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222195016095.png)

![image-20211222195157773](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222195157773.png)

![image-20211222195556713](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222195556713.png)

配置环境变量

将其bin目录加到系统的path下



下载分词postman



**开启es**

直接点击bin下面的bat

![image-20211223201319708](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223201319708.png)

**查看es集群的健康状态**

![image-20211222202502190](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222202502190.png)

**查看结点**

单节点

![image-20211222202625372](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222202625372.png)

**查看有多少索引**

![image-20211222202826605](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222202826605.png)

yellow不是最健康的状态，没有备份

**删除索引**

![image-20211222202938059](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222202938059.png)

![image-20211222203309461](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222203309461.png)

建立索引

![image-20211222203441569](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222203441569.png)

![image-20211222203600792](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222203600792.png)

**插入数据**

![image-20211222203857088](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222203857088.png)

**查询数据**

![image-20211222204007243](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204007243.png)

改数据直接在body里面修改

**删除数据**

![image-20211222204110358](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204110358.png)

**搜索**

先插入几条数据

![image-20211222204250256](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204250256.png)

![image-20211222204318597](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204318597.png)

![image-20211222204346696](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204346696.png)

搜索

![image-20211222204447347](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204447347.png)

![image-20211222204544385](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204544385.png)

![image-20211222204623529](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204623529.png)

![image-20211222204913445](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211222204913445.png)



## SpringBoot整合Elasticsearch

![image-20211223191420514](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223191420514.png)

```java
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-elasticsearch</artifactId>
</dependency>
```

![image-20211223193834618](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223193834618.png)

![image-20211223193855529](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223193855529.png)

解决redis和es的netty冲突问题

管理bean的生命周期，管理bean初始化的方法

```java
@PostConstruct //解决netty启动冲突问题
public void init(){
    System.setProperty("es.set.netty.runtime.available.processors","false");
}
```

将贴子存到es服务器里面，我们去搜索帖子。

配置帖子表和es索引的对应关系，每个字段对应什么样的类型，注解配置

将实体数据和es里面的数据进行映射，映射到那个索引，那个字段，那个分区，那个副本

![image-20211223195250345](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223195250345.png)

分词器，拆分更可能多的词，用最聪明的分词器

![image-20211223195817616](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223195817616.png)

dao里面定义接口

![image-20211223200003839](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200003839.png)

@Mapper是mybatis专用注解，@Repository是数据访问层使用的注解。继承spring默认接口es，加上泛型实体类和主键类型

![image-20211223200215408](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200215408.png)

创建测试类测试

从mysql数据库中取数据，再将其转存到es中。

![image-20211223200433990](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200433990.png)

先打开postman里面有没有帖子相关内容（服务器里面有哪些索引）

![image-20211223200549716](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200549716.png)

添加数据

（前提Kafka，zookeeper，es都启动）

![image-20211223200758445](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200758445.png)

![image-20211223200903643](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200903643.png)

查数据

![image-20211223205316357](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223205316357.png)

![image-20211223200953363](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211223200953363.png)

Page不是我们自己写的类，是别人封装的

**搜索测试类**

```java
@Test
public void testSearchTemplate(){
    SearchQuery searchQuery=new NativeSearchQueryBuilder()
            .withQuery(QueryBuilders.multiMatchQuery("互联网寒冬","title","content"))//搜索条件（即从title和content）
            .withSort(SortBuilders.fieldSort("type").order(SortOrder.DESC))//排序条件（按照type是否置顶，score帖子分值，时间依次排序）
            .withSort(SortBuilders.fieldSort("score").order(SortOrder.DESC))
            .withSort(SortBuilders.fieldSort("createTime").order(SortOrder.DESC))
            .withPageable(PageRequest.of(0,10))//分页条件
            .withHighlightFields(
                    new HighlightBuilder.Field("title").preTags("<em>").postTags("</em>"),
                    new HighlightBuilder.Field("content").preTags("<em>").postTags("</em>")
            ).build();//哪些词高亮显示（前后置标签）

    Page<DiscussPost> page = elasticTemplate.queryForPage(searchQuery, DiscussPost.class, new SearchResultMapper() {
        @Override
        public <T> AggregatedPage<T> mapResults(SearchResponse response, Class<T> aClass, Pageable pageable) {
            SearchHits hits=response.getHits();
            if(hits.getTotalHits()<=0){
                return null;
            }

            //遍历命中的数据
            List<DiscussPost> list=new ArrayList<>();
            for (SearchHit hit : hits) {
                DiscussPost post=new DiscussPost();
                //将数据包装到实体类返回（在hit里将json封装成了map）
                String id = hit.getSourceAsMap().get("id").toString();
                post.setId(Integer.valueOf(id));//将字符串id转为数字

                String userId = hit.getSourceAsMap().get("userId").toString();
                post.setUserId(Integer.valueOf(userId));
                //获得原始的title，content（可能里面没有关键词在content里）
                String title = hit.getSourceAsMap().get("title").toString();
                post.setTitle(title);

                String content = hit.getSourceAsMap().get("content").toString();
                post.setContent(content);

                String status = hit.getSourceAsMap().get("status").toString();
                post.setStatus(Integer.valueOf(status));

                //日期是long类型的字符串，将其先转为long再转为日期
                String createTime = hit.getSourceAsMap().get("createTime").toString();
                post.setCreateTime(new Date(Long.valueOf(createTime)));

                //处理高亮显示的结果
                //（获得高亮显示的内容）
                HighlightField titleField = hit.getHighlightFields().get("title");
                if(titleField!=null){
                    //不为空，重新设置title（只要第一个高亮部分）
                    post.setTitle(titleField.getFragments()[0].toString());
                }

                HighlightField contentField = hit.getHighlightFields().get("content");
                if(contentField!=null){
                    post.setContent(contentField.getFragments()[0].toString());
                }

                list.add(post);

            }

            return new AggregatedPageImpl(list,pageable,
                    hits.getTotalHits(),response.getScrollId(),hits.getMaxScore());
        }
    });

    //多少行，多少页，当前在哪一页，当前页显示了多少条数据
    System.out.println(page.getTotalElements());
    System.out.println(page.getTotalPages());
    System.out.println(page.getNumber());
    System.out.println(page.getSize());
    for (DiscussPost post : page) {
        System.out.println(post);
    }
}
```

![image-20211224112533660](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211224112533660.png)



## 开发社区搜索功能

![image-20211224135226243](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211224135226243.png)

```java
//搜索表现层(传入关键词，分页自己封装的page)
//get请求参数不能用请求体来传，用路径后加？，用路径中的某一级来传
//search?keyword=xxx
@RequestMapping(path = "/search",method = RequestMethod.GET)
public String search(String keyword, Page page, Model model){
    //搜索帖子集合,es里面的当前页是从0开始，我们封装的page是从1开始，减1
    org.springframework.data.domain.Page<DiscussPost> discussPosts =
            elasticsearchService.searchDiscussPost(keyword, page.getCurrent() - 1, page.getLimit());
    //聚合需要的数据
    List<Map<String,Object>> searchList=new ArrayList<>();

    //判断帖子搜索结果
    if(discussPosts!=null){
        //遍历搜索结果
        for (DiscussPost discussPost : discussPosts) {
            Map<String,Object> map=new HashMap<>();
            //将贴子、帖子作者、点赞数量存入map
            map.put("post",discussPost);
            map.put("user",userService.findUserById(discussPost.getUserId()));
            map.put("likeCount",likeService.findEntityLikeCount(ENTITY_TYPE_POST,discussPost.getId()));
            searchList.add(map);
        }

    }
    //将最终数据传给页面
    model.addAttribute("discussPosts",searchList);
    //关键词也传给模板页面
    model.addAttribute("keyword",keyword);

    //设置分页信息，路径、数据条数
    page.setPath("/search?keyword="+keyword);
    page.setRows(discussPosts==null?0:discussPosts.getTotalPages());

    return "/site/search";
}
```

![image-20211224153655241](https://pic-bed-1303913583.cos.ap-nanjing.myqcloud.com/img/image-20211224153655241.png)